-- 1) Which movie has the highest average rating?
SELECT m.movie_id, m.title, ROUND(AVG(r.rating), 3) AS avg_rating, COUNT(*) AS n_ratings
FROM ratings r
JOIN movies m ON m.movie_id = r.movie_id
GROUP BY m.movie_id
ORDER BY avg_rating DESC, n_ratings DESC
LIMIT 1;

-- 2) Top 5 genres with the highest average rating
SELECT g.name AS genre, ROUND(AVG(r.rating), 3) AS avg_rating, COUNT(*) AS n_ratings
FROM ratings r
JOIN movie_genres mg ON mg.movie_id = r.movie_id
JOIN genres g ON g.genre_id = mg.genre_id
GROUP BY g.name
HAVING COUNT(*) >= 50
ORDER BY avg_rating DESC
LIMIT 5;

-- 3) Director with the most movies in this dataset (from OMDb)
SELECT d.name AS director, COUNT(*) AS movie_count
FROM movie_directors md
JOIN directors d ON d.director_id = md.director_id
GROUP BY d.name
ORDER BY movie_count DESC, d.name ASC
LIMIT 1;

-- 4) Average rating of movies released each year
SELECT m.release_year AS year, ROUND(AVG(r.rating), 3) AS avg_rating, COUNT(*) AS n_ratings, COUNT(DISTINCT m.movie_id) AS n_movies
FROM ratings r
JOIN movies m ON m.movie_id = r.movie_id
WHERE m.release_year IS NOT NULL
GROUP BY m.release_year
ORDER BY year;
