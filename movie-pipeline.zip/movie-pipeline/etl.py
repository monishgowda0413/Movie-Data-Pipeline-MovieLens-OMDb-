\
import argparse, csv, json, os, re, sqlite3, time
from pathlib import Path
from typing import List, Tuple, Optional
import requests

TITLE_YEAR_RE = re.compile(r"^(?P<title>.+?)\s*\((?P<year>\d{4})\)\s*$")

def parse_title_year(raw_title: str) -> Tuple[str, Optional[int]]:
    m = TITLE_YEAR_RE.match(raw_title)
    if not m:
        return raw_title, None
    title = m.group("title").strip()
    year = int(m.group("year"))
    return title, year

def ensure_schema(conn: sqlite3.Connection, schema_path: str):
    with open(schema_path, "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.commit()

def insert_movies_genres(conn: sqlite3.Connection, movies_csv: str):
    # movies.csv: movieId,title,genres
    with open(movies_csv, "r", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        for row in rdr:
            mid = int(row["movieId"])
            raw_title = row["title"].strip()
            clean_title, year = parse_title_year(raw_title)

            conn.execute(
                "INSERT OR IGNORE INTO movies(movie_id, title, clean_title, release_year) VALUES (?,?,?,?)",
                (mid, raw_title, clean_title, year),
            )

            genres = row["genres"].split("|") if row["genres"] else []
            for g in genres:
                g = g.strip()
                if not g or g == "(no genres listed)":
                    continue
                conn.execute("INSERT OR IGNORE INTO genres(name) VALUES (?)", (g,))
                gid = conn.execute("SELECT genre_id FROM genres WHERE name=?", (g,)).fetchone()[0]
                conn.execute(
                    "INSERT OR IGNORE INTO movie_genres(movie_id, genre_id) VALUES (?,?)",
                    (mid, gid),
                )
    conn.commit()

def insert_ratings(conn: sqlite3.Connection, ratings_csv: str, chunk_size: int = 50000):
    # ratings.csv: userId,movieId,rating,timestamp
    with open(ratings_csv, "r", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        batch = []
        for row in rdr:
            batch.append((
                int(row["userId"]),
                int(row["movieId"]),
                float(row["rating"]),
                row["timestamp"]
            ))
            if len(batch) >= chunk_size:
                conn.executemany(
                    "INSERT OR IGNORE INTO ratings(user_id, movie_id, rating, rated_at) VALUES (?,?,?,?)",
                    batch
                )
                batch.clear()
        if batch:
            conn.executemany(
                "INSERT OR IGNORE INTO ratings(user_id, movie_id, rating, rated_at) VALUES (?,?,?,?)",
                batch
            )
    conn.commit()

class KeyRotator:
    def __init__(self, keys: List[str], per_key_daily_limit: int = 1000):
        self.keys = [k.strip() for k in keys if k.strip()]
        self.limit = per_key_daily_limit
        self.idx = 0
        self.counts = [0] * len(self.keys)
        if not self.keys:
            raise ValueError("No OMDb keys provided.")

    def next_key(self) -> str:
        start = self.idx
        # advance if current key is exhausted
        while self.counts[self.idx] >= self.limit:
            self.idx = (self.idx + 1) % len(self.keys)
            if self.idx == start:
                raise RuntimeError("All OMDb keys exhausted for today.")
        key = self.keys[self.idx]
        self.counts[self.idx] += 1
        return key

def omdb_fetch(session: requests.Session, title: str, year: Optional[int], rotator: KeyRotator) -> Optional[dict]:
    def call(params):
        time.sleep(0.1)  # gentle rate
        params = dict(params)  # copy
        params["apikey"] = rotator.next_key()
        resp = session.get("http://www.omdbapi.com/", params=params, timeout=20)
        if resp.status_code != 200:
            return None
        data = resp.json()
        if data.get("Response") == "True":
            return data
        return None

    params = {"t": title, "type": "movie"}

    if year:
        data = call({**params, "y": str(year)})
        if data:
            return data

    data = call(params)
    if data:
        return data

    safe_title = re.sub(r"[^\w\s]", " ", title).strip()
    safe_title = re.sub(r"\s+", " ", safe_title)
    if safe_title and safe_title.lower() != title.lower():
        data = call({**params, "t": safe_title})
        if data:
            return data

    return None

def upsert_omdb(conn: sqlite3.Connection, movie_id: int, payload: dict):
    imdb_id = payload.get("imdbID")
    fields = (
        imdb_id,
        payload.get("Title"),
        payload.get("Year"),
        payload.get("Rated"),
        payload.get("Released"),
        payload.get("Runtime"),
        payload.get("Language"),
        payload.get("Country"),
        payload.get("Awards"),
        payload.get("Metascore"),
        payload.get("imdbRating"),
        payload.get("imdbVotes"),
        payload.get("BoxOffice"),
        payload.get("Plot"),
        json.dumps(payload, ensure_ascii=False)
    )
    conn.execute("""
        INSERT OR IGNORE INTO omdb(
            movie_id, imdb_id, title, year, rated, released, runtime, language, country,
            awards, metascore, imdb_rating, imdb_votes, box_office, plot, raw_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (movie_id, *fields))

    directors = (payload.get("Director") or "").strip()
    if directors:
        names = [n.strip() for n in directors.split(",") if n.strip()]
        for name in names:
            conn.execute("INSERT OR IGNORE INTO directors(name) VALUES (?)", (name,))
            did = conn.execute("SELECT director_id FROM directors WHERE name=?", (name,)).fetchone()[0]
            conn.execute(
                "INSERT OR IGNORE INTO movie_directors(movie_id, director_id) VALUES (?,?)",
                (movie_id, did)
            )

def enrich_with_omdb(conn: sqlite3.Connection, keys: List[str], limit: Optional[int]):
    rotator = KeyRotator(keys)
    session = requests.Session()
    rows = conn.execute("SELECT movie_id, clean_title, release_year FROM movies ORDER BY movie_id").fetchall()

    already = set(x[0] for x in conn.execute("SELECT movie_id FROM omdb").fetchall())
    count = 0
    for movie_id, title, year in rows:
        if movie_id in already:
            continue
        if limit is not None and count >= limit:
            break
        try:
            data = omdb_fetch(session, title, year, rotator)
            if data:
                upsert_omdb(conn, movie_id, data)
                conn.commit()
                count += 1
                if count % 25 == 0:
                    print(f"[OMDb] enriched {count} movies...")
        except RuntimeError as ex:
            print(f"[STOP] {ex}")
            break
        except Exception as ex:
            print(f"[WARN] movie_id={movie_id} title='{title}': {ex}")
            continue

def parse_db_path(db_url: str) -> str:
    if db_url.startswith("sqlite:///"):
        return db_url.replace("sqlite:///", "", 1)
    return db_url

def main():
    ap = argparse.ArgumentParser(description="Movie ETL with OMDb enrichment")
    ap.add_argument("--data-dir", required=True, help="Folder containing movies.csv and ratings.csv")
    ap.add_argument("--schema", required=True, help="Path to schema.sql")
    ap.add_argument("--db-url", required=True, help="sqlite:///path/to.db or plain path")
    ap.add_argument("--omdb-keys", dest="omdb_keys", required=True, help="Comma-separated OMDb keys (up to 10)")
    ap.add_argument("--limit", type=int, default=None, help="Limit OMDb calls for quick tests")
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    movies_csv = str(data_dir / "movies.csv")
    ratings_csv = str(data_dir / "ratings.csv")

    db_path = parse_db_path(args.db_url)
    os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
    conn = sqlite3.connect(db_path)
    try:
        ensure_schema(conn, args.schema)
        insert_movies_genres(conn, movies_csv)
        insert_ratings(conn, ratings_csv)
        keys = [k.strip() for k in args.omdb_keys.split(",") if k.strip()]
        if not keys:
            raise SystemExit("Provide --omdb-keys \"k1,k2,...\"")
        enrich_with_omdb(conn, keys, args.limit)
    finally:
        conn.close()
    print("ETL complete.")

if __name__ == "__main__":
    main()
