PRAGMA foreign_keys = ON;

-- Core movies from MovieLens
CREATE TABLE IF NOT EXISTS movies (
  movie_id     INTEGER PRIMARY KEY,        -- MovieLens movieId
  title        TEXT NOT NULL,              -- raw title with (year)
  clean_title  TEXT NOT NULL,              -- title without (year)
  release_year INTEGER
);

-- Ratings from MovieLens
CREATE TABLE IF NOT EXISTS ratings (
  user_id   INTEGER,
  movie_id  INTEGER,
  rating    REAL,
  rated_at  TEXT,
  PRIMARY KEY (user_id, movie_id, rated_at),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id)
);

-- Genres
CREATE TABLE IF NOT EXISTS genres (
  genre_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name     TEXT UNIQUE
);

CREATE TABLE IF NOT EXISTS movie_genres (
  movie_id INTEGER,
  genre_id INTEGER,
  PRIMARY KEY (movie_id, genre_id),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id),
  FOREIGN KEY (genre_id) REFERENCES genres(genre_id)
);

-- OMDb enrichment (1 row per movie)
CREATE TABLE IF NOT EXISTS omdb (
  movie_id     INTEGER UNIQUE,             -- link to MovieLens movie
  imdb_id      TEXT,
  title        TEXT,
  year         TEXT,
  rated        TEXT,
  released     TEXT,
  runtime      TEXT,
  language     TEXT,
  country      TEXT,
  awards       TEXT,
  metascore    TEXT,
  imdb_rating  TEXT,
  imdb_votes   TEXT,
  box_office   TEXT,
  plot         TEXT,
  raw_json     TEXT,                       -- full JSON for debugging
  PRIMARY KEY (movie_id),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id)
);

-- Directors normalized from OMDb (split on commas)
CREATE TABLE IF NOT EXISTS directors (
  director_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT UNIQUE
);

CREATE TABLE IF NOT EXISTS movie_directors (
  movie_id    INTEGER,
  director_id INTEGER,
  PRIMARY KEY (movie_id, director_id),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id),
  FOREIGN KEY (director_id) REFERENCES directors(director_id)
);
